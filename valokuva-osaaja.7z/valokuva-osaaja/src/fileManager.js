const fs = require('fs');
const targetDir = process.argv[2] || process.cwd()

fs.promises.readdir(targetDir)

    .then(filenames => {
        for (let filename of filenames) {
            console.log(filename)
        }
    })

    .catch(err => {
        console.log(err)
    })
