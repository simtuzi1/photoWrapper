var PouchDB = require('pouchdb');

db = new PouchDB('variableStorage');
