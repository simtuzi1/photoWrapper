const nodeDiskInfo = require('node-disk-info');
nodeDiskInfo.getDiskInfo()
  .then(devices => {
    output(devices);
  })
  .catch(err => {
        console.error(err);
  })

function range(end) {
  return Array.from({ length: end }, (_, index) => index);
}

function output(devices){
    let arr = range(devices.length);
    window.addEventListener('DOMContentLoaded', () => {
        const addText = (selector, text) => {
            const element = document.getElementById(selector)
          if (element){
            element.innerHTML += '<p id="selectable-device-num-' + arr.pop() + '">' + text + '</p>';
          }
        }
        for (const type of ['name']) {
            for (const device of devices) {
                addText(`${type}-dev`, device.mounted)
                console.log('Filesystem', device.filesystem, '\n');
            }
        }
    })
}
